var express = require("express");
var app = express();

app.use(express.static("public"));

 
app.get("/", function(req, res){
   res.render("home.ejs")
});

app.get("/fallinlovewith/:somedog", function(req, res){
   var somedog = req.params.somedog;
   res.render("love.ejs", {apple: somedog});
});

//list of book
app.get("/books", function(req, res) {
   var booklist = [
   {author:"Tom", title:"Hello"},
   {author:"Joe", title:"Goodbye"},
   {author:"Hand", title:"GOT"}
   ];
   
   res.render("books.ejs", {name: booklist})
})

app.listen(3000, function(){
    console.log("server started");
});
