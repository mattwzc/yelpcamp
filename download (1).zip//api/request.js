var request = require('request');
var express = require("express");
app = express();
app.set("view engine","ejs");

app.get("/", function(req, res){
    res.render("search");
    
})

app.get("/results", function(req, res){
    var query = req.query.search;
    var url = "http://www.omdbapi.com/?s="+ query +"&apikey=5a4d840f";
    console.log(url);
    request(url, function(error, response,body){
        if(!error && response.statusCode == 200) {
        var temp = JSON.parse(body);
        res.render("results", {temp:temp});
}
    });
});



app.listen(3000, function(){
    console.log("movie server started");
});
 